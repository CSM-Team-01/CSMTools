import random

nombre = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]


def nombre_():
    for i in range(500):
        print("0" + str(str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre)) + str(random.choice(nombre))))
