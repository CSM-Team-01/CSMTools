import os
import webbrowser
import base64

def help():
    options = input("1. createFile()\n2. encodeFile()\n3. decodeFile()")
    if options == "1":
        print("createFile(title,text,type(html,txt,js,py,exe),intents(w,x,a,b,t))")

    if options == "2":
        print("encodeFile(title,base(64,32,16))")

    if options == "3":
        print("decodeFile(title,base(64,32,16))")



    help = input("Need more help ? type YES")
    if help == "YES":
        actions = input("1 | Discord\n2 | Website\n")
        if actions == "1":
            webbrowser.open("https://dsc.gg/csmteam")
        if actions == "2":
            webbrowser.open("https://csm.teamcsm.repl.co#support")
        else:
            print("CreateFile by CSM owned by BlueRed_")


def encodeFile(titre,base):
    if base == "64":
        eF = open(titre ,"r")
        eF_content = eF.readlines
        eF_utf8 = eF.encode("UTF-8")
        eF_utf8_b64 = base64.b64encode(eF_utf8)
        eF.write(eF_utf8_b64)

    if base == "32":
        eF = open(titre ,"r")
        eF_content = eF.readlines
        eF_utf8 = eF.encode("UTF-8")
        eF_utf8_b32 = base64.b32encode(eF_utf8)
        eF.write(eF_utf8_b32)

    if base == "16":
        eF = open(titre ,"r")
        eF_content = eF.readlines
        eF_utf8 = eF.encode("UTF-8")
        eF_utf8_b16 = base64.b16encode(eF_utf8)
        eF.write(eF_utf8_b16)


def decodeFile(titre,base):
    if base == "64":
        dF = open(titre ,"r")
        dF_content = dF.readlines
        dF_utf8 = dF_content.decode("UTF-8")
        dF_utf8_b64 = base64.b64decode(dF_utf8)
        dF.write(dF_utf8_b64)

    if base == "32":
        dF = open(titre ,"r")
        dF_content = dF.readlines
        dF_utf8 = dF_content.decode("UTF-8")
        dF_utf8_b32 = base64.b32decode(dF_utf8)
        dF.write(dF_utf8_b32)

    if base == "16":
        dF = open(titre ,"r")
        dF_content = dF.readlines
        dF_utf8 = dF_content.decode("UTF-8")
        dF_utf8_b16 = base64.b16decode(dF_utf8)
        dF.write(dF_utf8_b16)







def createFile(titre,contenu,type,intents):
    if intents != "w" or "x" or "a" or "b" or "t" or "w+" or "x+" or "a+" or "b+" or "t+":
        if type == "html":
            fhtml = open(titre + ".html", "a+")
            html_contenu = """
            <DOCTYPE html>
            <html>
                <head>
                    <title>CreateFilebyCSM</title>
                </head>
                <body>

                </body>
            </html>
        
            """ + contenu

            fhtml.writelines(html_contenu)

        
            if type == "txt":
                ftxt = open(titre + ".txt", "a+")
                txt_contenu = """
                CreateFilebyCSM
        
                """ + contenu

                ftxt.writelines(txt_contenu)


            if type == "js":
                fjs = open(titre + ".js", "a+")
                js_contenu = """
                # CreateFilebyCSM
        
                """

                fjs.writelines(js_contenu)


            if type == "py":
                fpy = open(titre + ".py", "a+")
                fpy.write("")
                py_contenu = """
                # CreateFilebyCSM
        
                """ + contenu

                fpy.writelines(py_contenu)


            if type == "exe":
                fexe = open(titre + ".exe", "a+")
                exe_contenu = """


                """ + contenu

                fexe.writelines(exe_contenu)


    if intents == "w" or "x" or "a" or "b" or "t" or "w+" or "x+" or "a+" or "b+" or "t+":
        if type == "html":
            fhtml = open(titre + ".html", intents)
            html_contenu = """
            <DOCTYPE html>
            <html>
                <head>
                    <title>CreateFilebyCSM</title>
                </head>
                <body>

                </body>
            </html>
        
            """ + contenu

            fhtml.writelines(html_contenu)

        
            if type == "txt":
                ftxt = open(titre + ".txt", intents)
                txt_contenu = """
                CreateFilebyCSM
        
                """ + contenu

                ftxt.writelines(txt_contenu)


            if type == "js":
                fjs = open(titre + ".js", intents)
                js_contenu = """
                # CreateFilebyCSM
        
                """

                fjs.writelines(js_contenu)


            if type == "py":
                fpy = open(titre + ".py", intents)
                fpy.write("")
                py_contenu = """
                # CreateFilebyCSM
        
                """ + contenu

                fpy.writelines(py_contenu)


            if type == "exe":
                fexe = open(titre + ".exe", intents)
                exe_contenu = """


                """ + contenu

                fexe.writelines(exe_contenu)







os.system('pause')
