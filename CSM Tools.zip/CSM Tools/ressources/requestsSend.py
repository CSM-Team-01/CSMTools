import requests

def sendReq(content,webhook,username,auth):
    payload = {
        "content": content,
        "username": username
    }

    header = {
        "Authorization": auth
    }

    r = requests.post(webhook,data=payload,headers=header)