```
╔═══╗╔═══╗╔═╗╔═╗    ╔════╗        ╔╗
║╔═╗║║╔═╗║║║╚╝║║    ║╔╗╔╗║        ║║
║║ ╚╝║╚══╗║╔╗╔╗║    ╚╝║║╚╝╔══╗╔══╗║║ ╔══╗
║║ ╔╗╚══╗║║║║║║║      ║║  ║╔╗║║╔╗║║║ ║══╣
║╚═╝║║╚═╝║║║║║║║     ╔╝╚╗ ║╚╝║║╚╝║║╚╗╠══║
╚═══╝╚═══╝╚╝╚╝╚╝     ╚══╝ ╚══╝╚══╝╚═╝╚══╝
```

# CSM Tools
## CSM Tools is a lot of hackers tools

If you have any questions, error or you need help, join my discord
https://dsc.gg/csmteam
In CSM Tools you can

- Edit HTTP requests
- Create programs without know how code
- Scan networks
- Read and write into a obfusq file
- encode a file into base64 base32 base16
- others Discord tools
- And other...
- Control anything with brute forces

# How to code that ?

The project isn't open source, but you can install the project modules :

_os_

_pystyle_

_webbrowser_

_tkinter_

_random_

_sys_

_requests_

_time_

You can install it by the using **command prompt**

`CSM Tools create by CSM owned and code by BlueRed_`